package Animalshop;
public class AnimalTester {
    public static void main(String[] args) {
       Dog dog = new Dog("Kiara", "Chihuahua", "arf-arf", 1.2, "Cafe claro");
       Fish fish = new Fish("Goldfish", "cold", "red");
       
       System.out.println("Dog name: " + dog.getName());
       System.out.println("Dog breed: " + dog.getBreed());
       System.out.println("Bark noise: ");
         dog.bark();
         System.out.println("Dog weight: " + dog.getWeight());
         System.out.println("Dog colour: " + dog.getColour());

         System.out.println("Fish breed: " + fish.getBreed());
            System.out.println("water type: " + fish.getWaterType());
             System.out.println("Fish colour: " + fish.getColour());


    }
    
}
