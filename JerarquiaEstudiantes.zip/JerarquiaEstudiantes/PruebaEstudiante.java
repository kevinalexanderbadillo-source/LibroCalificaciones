package JerarquiaEstudiantes;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class PruebaEstudiante {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

        System.out.println("--- REGISTRO DE ESTUDIANTE ---");
        
        // Inicializar atributos mediante teclado
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Apellido Paterno: ");
        String apPaterno = scanner.nextLine();
        
        System.out.print("Apellido Materno: ");
        String apMaterno = scanner.nextLine();
        
        System.out.print("Fecha de nacimiento (dd/MM/yyyy): ");
        Date fechaNac = null;
        try {
            fechaNac = formatoFecha.parse(scanner.nextLine());
        } catch (ParseException e) {
            System.out.println("Formato de fecha inválido. Se usará la fecha actual.");
            fechaNac = new Date();
        }

        System.out.print("ID del Alumno: ");
        String id = scanner.nextLine();
        
        System.out.print("Carrera (Matemática, Ciencias, Informática, Computacion, etc.): ");
        String carrera = scanner.nextLine();
        
        System.out.print("Título a obtener (Licenciatura, Ingenieria, Master): ");
        String titulo = scanner.nextLine();
        
        int anioGrad = 0;
        while (true) {
            try {
                System.out.print("Año de graduación esperado: ");
                anioGrad = Integer.parseInt(scanner.nextLine());
                break;
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Debe ingresar un número entero.");
            }
        }

        // Instanciar el objeto Estudiante
        Estudiante estudiante = new Estudiante(nombre, apPaterno, apMaterno, fechaNac, id, carrera, titulo, anioGrad);

        // Desplegar datos mediante métodos accesores/toString
        System.out.println("\n" + estudiante.toString() + "\n");

        // Solicitar el número de calificaciones
        int numCalificaciones = 0;
        while (true) {
            try {
                System.out.print("¿Cuántas calificaciones desea ingresar para el cálculo del promedio? ");
                numCalificaciones = Integer.parseInt(scanner.nextLine());
                if (numCalificaciones > 0) {
                    break;
                }
                System.out.println("Debe ingresar al menos una calificación.");
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Debe ingresar un número entero.");
            }
        }
        
        // Almacenar en un arreglo e iterar con un ciclo for
        String[] calificaciones = new String[numCalificaciones];
        for (int i = 0; i < numCalificaciones; i++) {
            System.out.print("Ingrese calificación #" + (i + 1) + " (A, A-, B+, B, B-, C+, C, D, F): ");
            calificaciones[i] = scanner.nextLine();
        }

        // Llamar al método calcularPromedio
        estudiante.calcularPromedio(numCalificaciones, calificaciones);

        // AQUI ESTÁ EL CAMBIO: Se usa getPromCalif() en lugar de obtenerPromCalif()
        System.out.println("\nEl promedio calculado del estudiante es: " + String.format("%.2f", estudiante.getPromCalif()));

        // Preguntar al usuario si desea cambiar la carrera
        System.out.print("\n¿Desea cambiar de carrera al estudiante? (si/no): ");
        String respuesta = scanner.nextLine();

        if (respuesta.equalsIgnoreCase("si")) {
            System.out.print("Ingrese la nueva carrera: ");
            String nuevaCarrera = scanner.nextLine();
            
            // AQUI ESTÁN LOS CAMBIOS: Se usa setCarrera() y getCarrera()
            estudiante.setCarrera(nuevaCarrera);
            System.out.println("La nueva carrera del estudiante es: " + estudiante.getCarrera());
        }

        // Mensaje de fin del programa
        System.out.println("Fin del programa.");
        scanner.close();
    }
}