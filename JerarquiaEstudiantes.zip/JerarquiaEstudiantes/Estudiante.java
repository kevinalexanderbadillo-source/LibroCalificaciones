package JerarquiaEstudiantes;

import java.util.Date;

public class Estudiante extends Persona {
    private String id;
    private double promCalif;
    private String carrera;
    private String titulo;
    private int anioGraduacion;

    public Estudiante(String nombre, String apellidoPaterno, String apellidoMaterno, Date fechaNacimiento,
            String id, String carrera, String titulo, int anioGraduacion) {
        super(nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento);
        this.id = id;
        this.carrera = carrera;
        this.titulo = titulo;
        this.anioGraduacion = anioGraduacion;
        this.promCalif = 0.0; // Inicia en 0 hasta que se calcule
    }

    
    //            GETTERS Y SETTERS
    

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getPromCalif() {
        return promCalif;
    }

    public void setPromCalif(double promCalif) {
        this.promCalif = promCalif;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnioGraduacion() {
        return anioGraduacion;
    }

    public void setAnioGraduacion(int anioGraduacion) {
        this.anioGraduacion = anioGraduacion;
    }

  
    //             MÉTODOS DE LA CLASE
    

    // Método para calcular el promedio basado en un arreglo de calificaciones y su esquema de puntos
    public void calcularPromedio(int numCalificaciones, String[] calificaciones) {
        double sumaPuntos = 0.0;

        for (int i = 0; i < numCalificaciones; i++) {
            switch (calificaciones[i].toUpperCase()) {
                case "A":
                    sumaPuntos += 4.0;
                    break;
                case "A-":
                    sumaPuntos += 3.67;
                    break;
                case "B+":
                    sumaPuntos += 3.33;
                    break;
                case "B":
                    sumaPuntos += 3.0;
                    break;
                case "B-":
                    sumaPuntos += 2.67;
                    break;
                case "C+":
                    sumaPuntos += 2.33;
                    break;
                case "C":
                    sumaPuntos += 2.0;
                    break;
                case "D":
                    sumaPuntos += 1.0;
                    break;
                case "F":
                    sumaPuntos += 0.0;
                    break;
                default:
                    break; // Ignorar entradas no válidas
            }
        }

        if (numCalificaciones > 0) {
            this.promCalif = sumaPuntos / numCalificaciones;
        }
    }

    // Sobrescritura de toString para imprimir todos los datos con formato
    @Override
    public String toString() {
        // Nota: Se asume que obtenerNombreCompleto() y obtenerFechaNacimientoFormateada() 
        // vienen heredados correctamente de la clase Persona.
        return "--- Datos del Estudiante ---\n" +
                "Nombre: " + obtenerNombreCompleto() + "\n" +
                "Fecha de Nacimiento: " + obtenerFechaNacimientoFormateada() + "\n" +
                "ID: " + getId() + "\n" +
                "Carrera: " + getCarrera() + "\n" +
                "Grado Obtenido: " + getTitulo() + "\n" +
                "Año Esperado de Graduación: " + getAnioGraduacion() + "\n" +
                "Promedio Actual: " + String.format("%.2f", getPromCalif());
    }
}