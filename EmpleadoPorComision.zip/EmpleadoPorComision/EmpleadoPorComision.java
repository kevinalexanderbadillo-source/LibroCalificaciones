    public class EmpleadoPorComision extends Object {

    private String nombre;
    private String apellidoPaterno;
    private String nss;
    private double comision;
    private double montoVentas;

    public EmpleadoPorComision(String primerNombre, String apellidoPaterno, String numeroSeguroS,
            double comision, double montoVentasBrutas) {
        nombre = primerNombre;
        this.apellidoPaterno = apellidoPaterno;
        nss = numeroSeguroS;
        this.comision = comision;
        montoVentas = montoVentasBrutas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getapellidoPaterno(){
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno){
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getNss(){
        return nss;
    }

    public void setNss(String nss){
        this.nss = nss;

    }

    public double getComision(){
        return comision ;
    }

    public void setComision(double comision){
         if(comision <=0.0 || comision >= 1.0 )
            throw new IllegalArgumentException(
        "La tarifa de comision debe ser > 0.0 y < 1,0");
        this.comision = comision;
    }

    public double getMontoVentas(){
       return montoVentas;
    }

    public void setMontoVentas(double ventasBrutas){
        if (montoVentas < 0.0)
            throw new IllegalArgumentException(
        "las ventas brutas deben ser >= 0");
        this.montoVentas = ventasBrutas;
    }
    
    public double ingresos(){
        return comision * montoVentas; 
    }

    // devolver la representacion String del obejto EmpleadoPorComision
    @Override
    public String toString(){
    return String.format("%s: %s %s%n%s: %s%n%s: %,2f%n%s: %.2f", 
    "Empleado por comision", nombre, apellidoPaterno, 
    "numero de seguro social", nss,
    "ventas brutas", montoVentas, 
    "tarifa por comision", comision);
    }





    
}
