public class EmpleadoPorComision extends Empleado {
    // Comisión aplicada a las ventas.
    private double tarrifaComision;

    // Total de ventas del empleado.
    private double ventasBrutas;

    // Crea un empleado por comisión.
    public EmpleadoPorComision(String primerNombre, String apellidoPaterno, String numeroSeguroSocial,
            double tarrifaComision, double ventasBrutas) 
            {

        super(primerNombre, apellidoPaterno, numeroSeguroSocial);

        this.tarrifaComision = tarrifaComision;
        this.ventasBrutas = ventasBrutas;   
        this.montoVentas = montoVentas;
    }

    // Devuelve el nombre.
    public String getNombre() {
        return obtenerPrimerNombre();
    }

    // Devuelve el apellido.
    public String getApellidoPaterno() {
        return obtenerApellidoPaterno();
    }

    // Devuelve el NSS.
    public String getNumeroSeguroSocial() {
        return obtenerNumeroSeguroSocial();
    }

    // Devuelve la comisión.
    public double getComision() {
        return comision;
    }

    // Cambia la comisión.
    public void setComision(double comision) {
        if (comision <= 0.0 || comision >= 1.0) {
            throw new IllegalArgumentException("La comisión debe estar entre 0 y 1.");
        }
        this.comision = comision;
    }

    // Devuelve el monto de ventas.
    public double getMontoVentas() {
        return montoVentas;
    }

    // Cambia el monto de ventas.
    public void setMontoVentas(double montoVentas) {
        if (montoVentas < 0.0) {
            throw new IllegalArgumentException("El monto de ventas no puede ser negativo.");
        }
        this.montoVentas = montoVentas;
    }

    // Calcula los ingresos.
    @Override
    public double ingresos()
     {
        return comision * montoVentas;
    }

    // Muestra la información del empleado.
    @Override
    public String toString() {
        return String.format("%s:  %s%n%s:  %.2f%n%s: %.2f",
                "Empleado por comisión", super.toString(),
                "Monto de ventas", montoVentas, "Comisión",
                comision);
    }
}
